import csv
import os

# Function to write data to CSV file
def write_to_csv(filename, data):
    with open(filename, mode='w', newline='', encoding='utf-8') as file:
        writer = csv.writer(file)
        writer.writerows(data)

# Function to read data from CSV file
def read_from_csv(filename):
    if not os.path.exists(filename):
        return []
    with open(filename, mode='r', encoding='utf-8') as file:
        reader = csv.reader(file)
        return list(reader)
