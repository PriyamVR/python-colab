from csv_handler import write_to_csv, read_from_csv

# Path to the CSV file
student_database = 'students.csv'
student_fields = ['Admission no.', 'Name', 'Age', 'Email', 'Phone']


def add_student():
    print("-------------------------")
    print("Add Student Information")
    print("-------------------------")
    student_data = []
    for field in student_fields:
        value = input(f"Enter {field}: ")
        student_data.append(value)

    # Write to the CSV file
    existing_data = read_from_csv(student_database)
    existing_data.append(student_data)
    write_to_csv(student_database, existing_data)

    print("Data saved successfully")
    input("Press any key to continue")


def view_students():
    print("--- Student Records ---")
    records = read_from_csv(student_database)
    if not records:
        print("No students found.")
        return

    # Display student records
    for row in records:
        print("\t".join(row))

    input("Press any key to continue")


def search_student():
    print("--- Search Student ---")
    roll = input("Enter roll no. to search: ")
    records = read_from_csv(student_database)

    for row in records:
        if row[0] == roll:
            print("----- Student Found -----")
            print(f"Roll: {row[0]}")
            print(f"Name: {row[1]}")
            print(f"Age: {row[2]}")
            print(f"Email: {row[3]}")
            print(f"Phone: {row[4]}")
            break
    else:
        print("Roll No. not found in our database")

    input("Press any key to continue")


def update_student():
    print("--- Update Student ---")
    roll = input("Enter roll no. to update: ")
    records = read_from_csv(student_database)

    updated_data = []
    for row in records:
        if row[0] == roll:
            print("Student found, updating information...")
            updated_student = [roll]
            for field in student_fields[1:]:
                value = input(f"Enter new {field}: ")
                updated_student.append(value)
            updated_data.append(updated_student)
        else:
            updated_data.append(row)

    write_to_csv(student_database, updated_data)
    print("Student record updated successfully.")
    input("Press any key to continue")


def delete_student():
    print("--- Delete Student ---")
    roll = input("Enter roll no. to delete: ")
    records = read_from_csv(student_database)

    updated_data = [row for row in records if row[0] != roll]

    if len(updated_data) == len(records):
        print("Roll No. not found in our database")
    else:
        write_to_csv(student_database, updated_data)
        print(f"Roll no. {roll} deleted successfully.")

    input("Press any key to continue")
